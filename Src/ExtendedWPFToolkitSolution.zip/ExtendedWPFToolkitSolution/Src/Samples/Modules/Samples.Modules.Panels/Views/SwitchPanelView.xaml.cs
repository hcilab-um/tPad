﻿/************************************************************************

   Extended WPF Toolkit

   Copyright (C) 2010-2012 Xceed Software Inc.

   This program is provided to you under the terms of the Microsoft Public
   License (Ms-PL) as published at http://wpftoolkit.codeplex.com/license 

   This program can be provided to you by Xceed Software Inc. under a
   proprietary commercial license agreement for use in non-Open Source
   projects. The commercial version of Extended WPF Toolkit also includes
   priority technical support, commercial updates, and many additional 
   useful WPF controls if you license Xceed Business Suite for WPF.

   Visit http://xceed.com and follow @datagrid on Twitter.

  **********************************************************************/

using Microsoft.Practices.Prism.Regions;
using Samples.Infrastructure.Controls;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System;
using System.Windows;
using Xceed.Wpf.Toolkit.Panels;
using System.Collections.Generic;
using Xceed.Wpf.Toolkit;
using System.Text.RegularExpressions;
using System.IO;
using System.Diagnostics;
using System.Windows.Media.Imaging;

namespace Samples.Modules.Panels.Views
{
  /// <summary>
  /// Interaction logic for SwitchPanelView.xaml
  /// </summary>
  [RegionMemberLifetime( KeepAlive = false )]
  public partial class SwitchPanelView : DemoView
  {
    #region Members


    #endregion

    public SwitchPanelView()
    {
      InitializeComponent();
    }

    #region Event Handlers

    private void Hyperlink_RequestNavigate( object sender, System.Windows.Navigation.RequestNavigateEventArgs e )
    {
      Process.Start( new ProcessStartInfo( e.Uri.AbsoluteUri ) );
      e.Handled = true;
    }

    private void OnLayoutComboSelectionChanged( object sender, RoutedEventArgs e )
    {
      ComboBox comboBox = sender as ComboBox;
      bool isPlusPanel = (comboBox.SelectedIndex >= 2);

      if( _openSourceScreenShot != null )
        _openSourceScreenShot.Visibility = isPlusPanel ? Visibility.Visible : Visibility.Collapsed;
      if( _openSourceScreenShotDesc != null )
        _openSourceScreenShotDesc.Visibility = isPlusPanel ? Visibility.Visible : Visibility.Collapsed;
      if( _openSourceHyperlink != null )
        _openSourceHyperlink.Visibility = isPlusPanel ? Visibility.Visible : Visibility.Collapsed;
      if( _switchPanel != null )
        _switchPanel.Visibility = isPlusPanel ? Visibility.Collapsed : Visibility.Visible;

      if( isPlusPanel )
      {
        BitmapImage bitmapImage = new BitmapImage();
        string desc;

        bitmapImage.BeginInit();
        switch( comboBox.SelectedIndex )
        {
          case 2: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\Canvas.jpg", UriKind.Relative );
            desc = this.Resources[ "canvasPanelDescription" ] as string;
            break;
          case 3: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\Carousel.jpg", UriKind.Relative );
            desc = this.Resources[ "carouselDescription" ] as string;
            break;
          case 4: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\DockPanel.jpg", UriKind.Relative );
            desc = this.Resources[ "dockPanelDescription" ] as string;
            break;
          case 5: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\Grid.jpg", UriKind.Relative );
            desc = this.Resources[ "gridDescription" ] as string;
            break;
          case 6: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\StackPanel.jpg", UriKind.Relative );
            desc = this.Resources[ "stackPanelDescription" ] as string;
            break;
          case 7: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\StackedStackPanel.jpg", UriKind.Relative );
            desc = this.Resources[ "stackedStackPanelDescription" ] as string;
            break;
          case 8: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\AutoStretchStackPanel.jpg", UriKind.Relative );
            desc = this.Resources[ "autoStretchStackPanelDescription" ] as string;
              break;
          case 9: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\RelativeCanvas.jpg", UriKind.Relative );
            desc = this.Resources[ "relativeCanvasDescription" ] as string;
              break;
          case 10: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\RadialCanvas.jpg", UriKind.Relative );
            desc = this.Resources[ "radialCanvasDescription" ] as string;
            break;
          case 11: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\CameraPanel.jpg", UriKind.Relative );
            desc = this.Resources[ "cameraPanelDescription" ] as string;
            break;
          case 12: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\PerspectivePanel.jpg", UriKind.Relative );
            desc = this.Resources[ "perspectivePanelDescription" ] as string;
            break;
          case 13: 
            bitmapImage.UriSource = new Uri( "..\\OpenSourceImages\\AnimatedTimelinePanel.jpg", UriKind.Relative );
            desc = this.Resources[ "animatedTimelinePanelDescription" ] as string;
            break;
          default: throw new InvalidDataException( "LayoutcomboBox.SelectedIndex is not valid." );
        }
        bitmapImage.EndInit();

        if( _openSourceScreenShot != null )
          _openSourceScreenShot.Source = bitmapImage;
        if( _openSourceScreenShotDesc != null )
          _openSourceScreenShotDesc.Text = desc;
      }
    }

    private void OnSwitchPanelLayoutChanged( object sender, RoutedEventArgs e )
    {
    }


























    #endregion 

    #region Methods (Private)






























    #endregion

  }
}
